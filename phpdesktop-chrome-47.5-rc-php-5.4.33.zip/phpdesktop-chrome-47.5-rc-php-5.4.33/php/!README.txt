PHP binaries downloaded from windows.php.net.

Extensions were moved from ext/ directory to the root directory
to fix problem with loading extensions on Windows XP, see 
Issue 34 in PHP Desktop:
  https://code.google.com/p/phpdesktop/issues/detail?id=34
