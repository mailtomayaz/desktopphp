<style type="text/css">@import url("style.css");</style>
<a href="index.php">Go back to index</a>
| <a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>

<title>HTML 5 Video and accelerated content</title>
<h1>HTML 5 Video and accelerated content</h1>

<p>Use the "Back" option in the right mouse context menu
to go back to this page, after clicking on the links below.</p>

<a href="http://www.youtube.com/watch?v=siOHh0uzcuY&html5=True">
HTML 5 video</a><br>

<a href="http://mudcu.be/labs/JS1k/BreathingGalaxies.html">
Accelerated canvas</a><br>

<a href="http://www.webkit.org/blog-files/3d-transforms/poster-circle.html">
Accelerated layers</a><br>
