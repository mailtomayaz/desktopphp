<?php
print('<style type="text/css">@import url("style.css");</style>');
print("<a href='javascript:history.go(-1)'>Go back</a><br>");
print("Printing a secret string: XuXuXaaa");
?>